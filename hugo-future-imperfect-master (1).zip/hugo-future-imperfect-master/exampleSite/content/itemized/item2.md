+++
type = "itemized"
author = "George Jetson"
date = "2017-06-22"
title = "Fancy App 2"
description = "Application for doing cool things."
featured = ""
featuredpath = ""
featuredalt = ""
categories = [""]
linktitle = ""
format = "Golang"
link = "#"
+++

## App 2
